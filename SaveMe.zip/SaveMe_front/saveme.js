let companyEl = document.getElementById("company") 
let countryEl = document.getElementById("country")  
let cityEl = document.getElementById("city") 
let commentEl = document.getElementById("comment")
let urlEl = document.getElementById("url") 




// //Setting the url to the current tab's url 
// chrome.tabs.query({active:true, lastFocusedWindow:true}, function(tabs){ 
//     urlEl.value = tabs[0].url})



function saveForm(){ 
    let statusEl = document.querySelector('input[name="status"]:checked')

    fetch("http://127.0.0.1:8000/saveme/create/", {
        method: 'POST', 
        headers: {
            'Content-Type':'application/json'
        },
        body: JSON.stringify({
            "company":companyEl.value, 
            "country": countryEl.value, 
            "city": cityEl.value, 
            "comments": commentEl.value, 
            "URL": urlEl.value, 
            "status": statusEl.value
        })
    }) 

   
    .then(response => response.json()) 
    .then(data => console.log(data)) 
    .catch(error => console.error(error))  

    console.log(statusEl.value)
} 



function clearForm(){
    console.log("Cleared")

    companyEl.textContent = "" 
    countryEl.textContent = "" 
    cityEl.textContent = "" 
    commentEl.textContent = "" 
    urlEl.textContent = ""  

    setTimeout(function() {
        location.reload();
    }, 10000);
} 


